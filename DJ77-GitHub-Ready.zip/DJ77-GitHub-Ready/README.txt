DJ77 GitHub Pages upload files
Upload all four files to the repository root (top level):
- index.html (login page / website entry page)
- dj77-register.html
- dj77-homepage.html
- README.txt
Then enable GitHub Pages from Settings > Pages > Deploy from a branch > main > /(root) > Save.
Note: this is a front-end demo. Authentication uses browser localStorage/sessionStorage and is not secure production authentication. Do not use real passwords or payment details.
